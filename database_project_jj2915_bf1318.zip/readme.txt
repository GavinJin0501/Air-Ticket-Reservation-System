All source code files are in the folder named `airline'.

Other description files are outside the folder named `airline'.